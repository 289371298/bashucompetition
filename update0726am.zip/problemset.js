//在11号端口加载problemset
//需求参数：requireuser
//返回参数：type，name，acnum，trynum
var http=require("http");
var querystring=require('querystring');
var mysql=require("mysql");
var params;
var fs=require('fs');
var type=[],name=[],acnum=[],trynum=[];
var server=http.createServer(function(req,res)//传来的参数：requireuser，提出要求的用户
                              {if(req.url==="favicon.ico")return;
							   var body='',flag=0;
						       req.on('data',function(data)
							                         {console.log(data+"arrival");
						                              body+=data;
													  params=querystring.parse(decodeURIComponent(body));
						                              }
								      );
							   req.on('end',function(){res.setHeader('Access-Control-Allow-Origin','*');  
											           res.writeHead(200,{'Content-Type' : 'application/JSON'});
													   var level=connect_and_check(params);
													   if(level===1)//用户权限不足，临时权限用户
													    {res.write("Data Restricted");
							                             return;}
													   else//根据权限在数据库中查找
													    {connect_and_feed(level);
														 var obj=JSON.stringify(type,name,acnum,trynum);
							                             res.write(obj);
														 }
													  });
							  res.end();
							  });	
server.listen(11,"localhost",function(){
    console.log("开始监听11...");
});					  
function connect_and_check(params)
  {var connection=mysql.createConnection({host:'localhost',
	  user:'root',
	  password:'990311',
	  port:'3306',
	  database:'bsoj_users'
      });
   var ans;
   connection.connect();
   connection.query('select managelevel from users where username='+params.requireuser,
                    function(err,result)
					  {ans=result[0].managelevel;}
					);
   connection.end();
   return ans;   
   }
function connect_and_feed(managelevel)
  {var connection=mysql.createConnection({host:'localhost',
                                          user:'root',
	                                      password:'990311',
	                                      port:'3306',
	                                      database:'bsoj_problems'
                                         });
   connection.connect();
   connection.query('select * from problems',
     function(err,result)
	   {var tot=0,len=result.row;
		for(var i=0;i<len;i++)
		  {if(managelevel<result[i].level)continue;//目前是设置为不能看到严格大于自己managelevel的题目
           type[tot]=result[i].submittime;
		   name[tot]=result[i].name;
           acnum[tot]=result[i].acnum;
           trynum[tot]=result[i].trynum;
		   tot++;
		   }  			
	    }
                    );   
   connection.end();
   }